<?php

function cem_autocomplete_settings() {
    return array(
        'qb_query_builder_post_ids' => 'get_posts'
    );
}